AMARILLO
Copyright 2016 by Francis Studio

Thank you! for downloading my font.

The word "Amarillo" is a Filipino word which means "Marigold".

This font is free for PERSONAL USE. If you want to use it commercially, please consult me first by emailing me.
I would like to express my dearest gratitude to Pexels.com and to the photographer for the wonderful background for my fonts.

If you have questions, reactions and comments please email me at francisstudio14@gmail.com
And I will gladly reply to it as soon as possible.

Thank you again!

Every stroke is made with love, Hope you love it!

Francis John | Francis Studio